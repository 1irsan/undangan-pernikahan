<?php
$db = mysqli_connect('localhost','root', '', 'crud-php');

// cek koneksi

// if (!$db) {
//     echo 'gagal';
// }
// else {
//     echo 'berhasil';
// }
