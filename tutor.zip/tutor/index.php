<?php
if (isset($_GET['cari'])) {
   $cari = $_GET ['cari'];
   $query = "SELECT artikel.*, kategori.nama AS nama_kategori FROM artikel LEFT JOIN kategori ON artikel.kategori = kategori.id  WHERE artikel.judul LIKE '%$cari%' ORDER BY artikel.id DESC";

} else {
    $cari= '';
    $query = 'SELECT artikel.*, kategori.nama AS nama_kategori FROM artikel LEFT JOIN kategori ON artikel.kategori = kategori.id  ORDER BY artikel.id DESC';
}


$koneksi = mysqli_connect("localhost", "root", "", "crud");
$data = mysqli_query($koneksi, $query);

$judulArtikel = [];
while ($d = mysqli_fetch_assoc($data)) {
    $judulArtikel[] = $d;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Clean Blog - Start Bootstrap Theme</title>
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Font Awesome icons (free version)-->
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet"
        type="text/css" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800"
        rel="stylesheet" type="text/css" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
</head>

<body>
    <div class="container px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7">
                <a href="tambah.php" class="btn btn-primary my-5 mt-2">Tambah Artikel</a>
                <form methoed="GET">     
        <div class="from-group my-3">
            <label for="penulis" class="form-label">pencarian</label>
            <input type="text" class="form-control"  name="cari" placeholder= "pencarian" value = "<?= $cari?>" required>
       
        </div>
        <p><button type="submit" name="tambah-artikel" class="btn btn-primary" >cari</button></p>
    </form>

                <?php 
                    foreach ($judulArtikel as $artikel) {
                ?>

                <div class="post-preview">
                    <div>
                        <?php if (empty($artikel['foto'])) { ?>
                            <img style= "width:150px" src="foto/default.jpg" alt="">
                            <?php }  else { ?>
                        <img style= width:150px; src="foto/<?=$artikel ['foto']?> " alt="">
                        <?php }?>
                    </div>
                    <a href="post.html">
                        <h2 class="post-title">
                            <a href="edit.php?id=<?php echo $artikel['id']?>"> <?php echo $artikel['judul'] ?></a>
                            <a href="hapus.php?id=<?php echo $artikel['id']?> " onclick="return confirm('apakah anda yakin akan menghapus')"><i class="bi bi-trash-fill"></i></a>
                           
                        </h2>
                    </a>
                    <p class="post-meta">
                        Posted by
                        <a href="#!"><?php echo $artikel['penulis'] ?></a> </br>
                        tanggal
                    <a href="#!"><?php echo $artikel['tanggal'] ?></a> </br>
                        isi
                    <a href="#!"><?php echo $artikel['isi'] ?></a> </br>
                        kategori
                    <a href="#!"><?php echo $artikel['nama_kategori'] ?></a> 
                    </p>

                </div>

                <?php
                    } 
                ?>



            </div>
        </div>
    </div>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
</body>

</html>