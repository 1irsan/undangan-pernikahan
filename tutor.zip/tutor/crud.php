<?php
include "leyout/header.php";
$data_barang = select('SELECT * FROM barang');
?>
<div class="container mt-5"> 
    <h1>Data Barang</h1>
    <hr>
    <a href="from-tambah.php" class="btn btn-primary mb-1"> Tambah</a>
    <table class="table table-border table-hover mt-3">
        <thead>
            <tr>
                <th>Id</th>
                <th>Nama</th>
                <th>Jumlah</th>
                <th>Harga</th>
                <th>tanggal</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
          <?php $no  = 1; ?>
          <?php foreach ($data_barang as $barang ) : ?>
          <tr>
          <td><?= $no++; ?></td>
            <td><?= $barang['nama'] ;?></td>
            <td><?= $barang ['jumlah'];?></td>
            <td>Rp.<?= number_format($barang['harga'],0,',',',');?></td>
            <td><?= date('d-m-Y | H:i:s', strtotime($barang ['tanggal'])); ?></td>
            <td width="15%" class="tag-center">
            <button type="button" class="btn btn-primary">Ubah</button>
              <button type="button" class="btn btn-dark">Hapus</button>
            </td>
          </tr>
          <?php endforeach ?>
        </tbody>
</table>
</div>

<?php
include "leyout/footer.php";
?>
